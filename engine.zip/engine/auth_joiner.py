"""
Lord Vault Auth Joiner (OAuth2) - Forwarding alias to engine/joiner.py
"""
import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from engine.joiner import (
    main,
    validate_bot_and_guild,
    extract_user_id,
    resolve_invite_to_guild,
    load_config,
    save_config,
    load_tokens,
    load_proxies,
)

if __name__ == "__main__":
    main()
