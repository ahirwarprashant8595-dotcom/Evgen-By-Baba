import os
import random
import re
import subprocess
import time
import socket
import requests
from threading import Lock
from typing import Optional

import json

# Terminal ANSI colors matching Lord Vault style
P = "\033[38;2;121;3;255m"
C = "\033[38;2;3;248;252m"
G = "\033[38;2;68;255;0m"
D = "\033[38;2;92;94;91m"
R = "\033[0m"
Y = "\033[38;2;255;200;50m"
RD = "\033[38;2;255;80;80m"

DEFAULT_COUNTRIES = [
    "us", "gb", "de", "se", "jp", "ca", "fr", "nl", "ch", "sg", "au", "fi", "br", "es", "it"
]


class VPNManager:
    """Manages VPN mode and automated IP & Country rotation commands.
    Enhanced for robust Mullvad CLI reconnects and socket permission settling."""

    def __init__(self, config: Optional[dict] = None):
        self.config = config or {}
        vpn_config = self.config.get("vpn", {}) if "vpn" in self.config else self.config
        self.enabled = bool(vpn_config.get("enabled", True))
        self.reconnect_command = str(vpn_config.get("reconnect_command", "") or "").strip()
        self.reconnect_delay = max(0.0, float(vpn_config.get("reconnect_delay", 4)))
        self.rotate_on_flag = bool(vpn_config.get("rotate_on_flag", True))
        self.rotate_every_account = bool(vpn_config.get("rotate_every_account", True))
        self.rotate_country = bool(vpn_config.get("rotate_country", True))
        self.max_retries = max(1, int(vpn_config.get("max_retries", 2)))

        custom_countries = vpn_config.get("country_list", [])
        if isinstance(custom_countries, list) and custom_countries:
            self.country_list = [str(c).strip().lower() for c in custom_countries if str(c).strip()]
        else:
            self.country_list = DEFAULT_COUNTRIES.copy()

        self._last_country = ""
        self._last_rotate_time = 0.0
        self._lock = Lock()
        self._current_ip = None
        self._rotation_count = 0

    def is_enabled(self) -> bool:
        return self.enabled

    def _clean_exe(self) -> Optional[str]:
        """Extract path to mullvad.exe without quotes, verifying file existence."""
        raw = self.reconnect_command
        default_paths = [
            r"C:\Program Files\Mullvad VPN\resources\mullvad.exe",
            r"C:\Program Files (x86)\Mullvad VPN\resources\mullvad.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Programs\Mullvad VPN\resources\mullvad.exe"),
        ]
        if raw and "mullvad" in raw.lower():
            match = re.search(r'("?([^"]*mullvad(?:\.exe)?)"?)', raw, re.IGNORECASE)
            if match:
                candidate = match.group(2).strip(' "\'')
                if os.path.exists(candidate):
                    return candidate
        for p in default_paths:
            if os.path.exists(p):
                return p
        return None

    def _extract_mullvad_exe(self) -> Optional[str]:
        exe = self._clean_exe()
        return f'"{exe}"' if exe else None

    def get_vpn_name(self) -> str:
        if self._clean_exe():
            return "Mullvad VPN"
        return "VPN"

    def get_next_country(self) -> str:
        """Get next country from country list, avoiding immediate repeats."""
        if not self.country_list:
            return "any"
        if len(self.country_list) == 1:
            return self.country_list[0]

        available = [c for c in self.country_list if c != self._last_country]
        if not available:
            available = self.country_list
        next_c = random.choice(available)
        self._last_country = next_c
        return next_c

    def get_status(self) -> tuple:
        """Return (state, info_dict) accurately without cmd shell quoting issues.
        state is 'connected', 'connecting', 'disconnected', or 'unknown'."""
        exe = self._clean_exe()
        if exe:
            # 1. Text status (fastest and most reliable across all Mullvad versions)
            try:
                res = subprocess.run([exe, "status"], capture_output=True, text=True, timeout=3)
                output = (res.stdout + "\n" + res.stderr).strip().lower()
                lines = [l.strip() for l in output.splitlines() if l.strip()]
                if lines:
                    first = lines[0]
                    ip_match = re.search(r'ipv4:\s*([0-9.]+)', output, re.IGNORECASE)
                    country_match = re.search(r'in\s+[^,]+,\s*([^.]+)', first)
                    country = country_match.group(1).strip() if country_match else ""
                    relay_match = re.search(r'connected to\s+([^\s]+)', first)
                    relay = relay_match.group(1).strip() if relay_match else ""
                    info = {
                        "ip": ip_match.group(1) if ip_match else None,
                        "country": country,
                        "relay": relay
                    }
                    if "connected" in first and "connecting" not in first and "disconnected" not in first:
                        return "connected", info
                    if "connecting" in first or "blocked" in first or "disconnecting" in first:
                        return "connecting", info
                    if "disconnected" in first:
                        return "disconnected", info
            except Exception:
                pass

            # 2. JSON status fallback
            try:
                res = subprocess.run([exe, "status", "-j"], capture_output=True, text=True, timeout=3)
                if res.returncode == 0 and res.stdout.strip():
                    try:
                        data = json.loads(res.stdout.strip())
                        raw_state = data.get("state")
                        state_str = ""
                        if isinstance(raw_state, dict):
                            state_str = list(raw_state.keys())[0].lower()
                        elif isinstance(raw_state, str):
                            state_str = raw_state.lower()

                        loc = data.get("details", {}).get("location", {}) or {}
                        info = {
                            "ip": loc.get("ipv4"),
                            "country": loc.get("country"),
                            "city": loc.get("city"),
                            "relay": loc.get("hostname"),
                        }

                        if "connected" in state_str and "connecting" not in state_str and "disconnected" not in state_str:
                            return "connected", info
                        if "connecting" in state_str or "disconnecting" in state_str or "blocked" in state_str:
                            return "connecting", info
                        if "disconnected" in state_str:
                            return "disconnected", info
                    except Exception:
                        pass
            except Exception:
                pass

        # 3. Check public API if Mullvad exit IP is detected
        try:
            r = requests.get("https://am.i.mullvad.net/json", timeout=3)
            if r.status_code == 200:
                d = r.json()
                if d.get("mullvad_exit_ip") or d.get("mullvad_using"):
                    return "connected", {"ip": d.get("ip"), "country": d.get("country")}
        except Exception:
            pass

        return "unknown", {}

    def _get_mullvad_status(self, mullvad_exe: str = None) -> str:
        st, _ = self.get_status()
        return st

    def _extract_ip_from_status(self, mullvad_exe: str = None) -> Optional[str]:
        _, info = self.get_status()
        return info.get("ip")

    def get_current_ip(self) -> Optional[str]:
        _, info = self.get_status()
        if info.get("ip"):
            self._current_ip = info["ip"]
            return self._current_ip
        for url in ["https://api.ipify.org", "https://ifconfig.me/ip", "https://icanhazip.com"]:
            try:
                resp = requests.get(url, timeout=3)
                if resp.status_code == 200 and resp.text.strip():
                    self._current_ip = resp.text.strip()
                    return self._current_ip
            except Exception:
                continue
        return self._current_ip

    def _vpn_log(self, msg: str, logger=None):
        ts = time.strftime("%H:%M:%S")
        prefix = f"  {D}[{ts}]{R} {C}[VPN]{R}     "
        formatted = f"{prefix}{msg}{R}"
        if logger and hasattr(logger, "log"):
            logger.log(formatted)
        elif callable(logger):
            logger(formatted)
        else:
            print(formatted)

    def startup_check(self, logger=None) -> bool:
        """Detect existing VPN connection or wait for in-progress connection on startup."""
        if not self.enabled:
            return False

        self._vpn_log(f"{C}Detecting VPN connection status...{R}", logger)
        status, info = self.get_status()

        # 1. Already connected -> keep it, do NOT disrupt
        if status == "connected":
            ip = info.get("ip") or self.get_current_ip() or "Active"
            country = info.get("country") or ""
            c_str = f" [{country.upper()}]" if country else ""
            self._vpn_log(f"{G}✓ VPN Detected: Connected{c_str} · IP: {ip}{R}", logger)
            self._current_ip = ip
            return True

        # 2. Actively connecting ("VPN connect ho raha hai") -> wait for it to settle
        if status == "connecting":
            self._vpn_log(f"{Y}⏳ VPN is connecting... Waiting for connection to settle...{R}", logger)
            wait_start = time.time()
            while time.time() - wait_start < 20.0:
                time.sleep(0.4)
                st, inf = self.get_status()
                if st == "connected":
                    if self._wait_for_connectivity(logger=logger, timeout=8.0):
                        ip = inf.get("ip") or self.get_current_ip() or "Active"
                        country = inf.get("country") or ""
                        c_str = f" [{country.upper()}]" if country else ""
                        self._vpn_log(f"{G}✓ VPN Connected{c_str} · IP: {ip}{R}", logger)
                        self._current_ip = ip
                        return True

        # 3. Disconnected -> initiate connection
        self._vpn_log(f"{Y}⏳ VPN not connected. Initiating connection...{R}", logger)
        return self.rotate_ip(logger=logger, reason="Startup auto-connect")

    def rotate_ip(self, logger=None, reason: str = "") -> bool:
        """Execute VPN reconnection & country rotation, actively verifying network socket unblock."""
        if not self.enabled:
            return False

        with self._lock:
            now = time.time()
            if now - self._last_rotate_time < 3.0:
                return True
            self._last_rotate_time = now

            reason_str = f" ({reason})" if reason else ""
            exe = self._clean_exe()
            selected_country = ""
            connected = False

            for attempt in range(1, self.max_retries + 1):
                # 1. Rotate country location if Mullvad & rotate_country is enabled
                if self.rotate_country and exe:
                    selected_country = self.get_next_country()
                    self._vpn_log(f"{G}Rotating VPN (Try {attempt}/{self.max_retries}) -> {C}{selected_country.upper()}{R}{reason_str}", logger)

                    try:
                        subprocess.run([exe, "relay", "set", "location", selected_country], capture_output=True, text=True, timeout=5)
                    except Exception:
                        pass

                    # Reconnect using Mullvad's native CLI
                    try:
                        curr_st, _ = self.get_status()
                        if curr_st == "connected":
                            cmd = [exe, "reconnect", "--wait"]
                        else:
                            cmd = [exe, "connect", "--wait"]
                        subprocess.run(cmd, capture_output=True, text=True, timeout=15)
                    except Exception:
                        pass
                elif exe:
                    self._vpn_log(f"{G}Rotating VPN IP (Try {attempt}/{self.max_retries}){reason_str}...{R}", logger)
                    try:
                        subprocess.run([exe, "reconnect", "--wait"], capture_output=True, text=True, timeout=30)
                    except Exception:
                        pass
                else:
                    exec_cmd = self.reconnect_command
                    if exec_cmd:
                        self._vpn_log(f"{G}Rotating VPN IP (Try {attempt}/{self.max_retries}){reason_str}...{R}", logger)
                        try:
                            subprocess.run(exec_cmd, shell=True, capture_output=True, text=True, timeout=25)
                        except Exception:
                            pass

                # 2. Wait and poll status until connected (fast polling)
                wait_start = time.time()
                announced_connecting = False
                while time.time() - wait_start < 18.0:
                    status, info = self.get_status()
                    if status == "connected":
                        connected = True
                        break
                    elif status == "connecting" and not announced_connecting:
                        self._vpn_log(f"{Y}⏳ Tunnel connecting...{R}", logger)
                        announced_connecting = True
                    time.sleep(0.3)

                # 3. Actively verify that Windows socket permissions (WFP / WinError 10013) & DNS have unblocked
                if connected:
                    is_online = self._wait_for_connectivity(logger=logger, timeout=6.0)
                    if is_online:
                        break
                    else:
                        connected = False  # Keep retrying next attempt

            if connected:
                self._rotation_count += 1
                country_str = f" [{selected_country.upper()}]" if selected_country else ""
                self._vpn_log(f"{G}✓ VPN Connected{country_str}{R}", logger)

                if self.reconnect_delay > 0:
                    time.sleep(self.reconnect_delay)

                ip = self.get_current_ip()
                if ip:
                    self._current_ip = ip

                return True

            # If failed after max_retries, keep VPN enabled so user isn't unshielded, but report warning
            self._vpn_log(f"{RD}⚠ VPN connection took longer than usual. Please check your VPN app.{R}", logger)
            return False

    @staticmethod
    def _wait_for_connectivity(logger=None, timeout: float = 6.0) -> bool:
        """Wait until network sockets and DNS resolution succeed without [WinError 10013]."""
        start = time.time()
        test_endpoints = [
            ("1.1.1.1", 443),
            ("discord.com", 443),
        ]
        while time.time() - start < timeout:
            for host, port in test_endpoints:
                try:
                    s = socket.create_connection((host, port), timeout=1.0)
                    s.close()
                    return True
                except Exception:
                    continue
            time.sleep(0.2)
        return False

    # Compatibility stubs
    def get_proxy(self):
        return None

    def release_proxy(self, proxy):
        pass

    def mark_bad(self, proxy):
        pass

    def mark_good(self, proxy):
        pass

    def pop_top(self):
        return None

    def pop_resi(self):
        return None

    def status_string(self) -> str:
        if not self.enabled:
            return "VPN Rotation: Disabled"
        vpn_name = self.get_vpn_name()
        ip = self._current_ip or "Active"
        return f"VPN: {vpn_name} | IP: {ip} | Rotations: {self._rotation_count}"


