import sys
import time
import os

# Ensure Windows terminal has ANSI and UTF-8 output enabled
try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

if os.name == 'nt':
    os.system('')

RAW_BANNER = """
  ██╗      ██████╗ ██████╗ ██████╗     ██╗   ██╗ █████╗ ██╗   ██╗██╗  ████████╗
  ██║     ██╔═══██╗██╔══██╗██╔══██╗    ██║   ██║██╔══██╗██║   ██║██║  ╚══██╔══╝
  ██║     ██║   ██║██████╔╝██║  ██║    ██║   ██║███████║██║   ██║██║     ██║   
  ██║     ██║   ██║██╔══██╗██║  ██║    ╚██╗ ██╔╝██╔══██║██║   ██║██║     ██║   
  ███████╗╚██████╔╝██║  ██║██████╔╝     ╚████╔╝ ██║  ██║╚██████╔╝███████╗██║   
  ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝       ╚═══╝  ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝   
       [ v4.2 PRO ]  ·  [ STEALTH BROWSER SOLVER ]  ·  [ CROWMail ENGINE ]"""

_ANIMATED_ONCE = False


def _hsv_to_rgb(h: float) -> tuple:
    """Convert hue 0.0-1.0 to RGB 0-255."""
    pos = h % 1.0
    h_i = int(pos * 6)
    f = pos * 6 - h_i
    q = int(255 * (1 - f))
    t = int(255 * f)
    if h_i == 0: return 255, t, 0
    elif h_i == 1: return q, 255, 0
    elif h_i == 2: return 0, 255, t
    elif h_i == 3: return 0, q, 255
    elif h_i == 4: return t, 0, 255
    else: return 255, 0, q


def render_rgb_line(line: str, line_idx: int, total_lines: int, offset: float = 0.0) -> str:
    """Render a single line with diagonal RGB gradient."""
    chars = []
    for char_idx, ch in enumerate(line):
        if ch == ' ':
            chars.append(' ')
            continue
        pos = (char_idx * 0.015 + line_idx * 0.038 + offset) % 1.0
        r, g, b = _hsv_to_rgb(pos)
        chars.append(f"\033[38;2;{r};{g};{b}m{ch}")
    return "".join(chars) + "\033[0m"


def render_rgb_banner(text: str = RAW_BANNER, offset: float = 0.0) -> str:
    """Render whole banner string with RGB rainbow gradient."""
    lines = text.strip('\n').split('\n')
    n = len(lines)
    return "\n".join(render_rgb_line(line, i, n, offset) for i, line in enumerate(lines))


def is_interactive() -> bool:
    if os.environ.get("GUI_MODE") == "1" or os.environ.get("NO_ANIMATION") == "1":
        return False
    try:
        return sys.stdout.isatty() or os.name == 'nt'
    except Exception:
        return True


def display_animated_banner(text: str = RAW_BANNER, force_animate: bool = False):
    """Display the RGB banner with an animated colorful wave on start."""
    global _ANIMATED_ONCE

    if os.environ.get("GUI_MODE") == "1":
        return

    lines = text.strip('\n').split('\n')
    n_lines = len(lines)

    if not force_animate and _ANIMATED_ONCE:
        print(render_rgb_banner(text, 0.12))
        return

    _ANIMATED_ONCE = True

    if not is_interactive():
        print(render_rgb_banner(text, 0.12))
        return

    # Hide cursor during animation for a clean visual look
    sys.stdout.write("\033[?25l")
    sys.stdout.flush()

    try:
        # Smooth RGB wave animation across banner
        frames = 22
        delay = 0.025
        for frame in range(frames):
            offset = frame * 0.045
            rendered = "\n".join(render_rgb_line(line, i, n_lines, offset) for i, line in enumerate(lines))
            if frame > 0:
                sys.stdout.write(f"\033[{n_lines}A\r")
            sys.stdout.write(rendered + "\n")
            sys.stdout.flush()
            time.sleep(delay)
    except Exception:
        # Fallback to static banner on any terminal quirk
        print(render_rgb_banner(text, 0.12))
    finally:
        # Always restore cursor
        sys.stdout.write("\033[?25h")
        sys.stdout.flush()


display_banner = display_animated_banner
