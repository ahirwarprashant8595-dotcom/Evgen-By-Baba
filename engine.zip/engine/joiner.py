import os
import sys
import json
import time
import random
import re
import base64
import threading
from urllib.parse import urlparse, parse_qs, quote
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

if os.name == "nt":
    os.system("")

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import requests
from curl_cffi import requests as curl_requests

# ── TrueColor Neon Theme ──────────────────────────────────────────────────
P = "\033[38;2;168;85;247m"     # Neon Purple
C = "\033[38;2;6;182;212m"      # Electric Cyan
G = "\033[38;2;16;185;129m"     # Emerald Green
Y = "\033[38;2;245;158;11m"     # Amber Gold
D = "\033[38;2;156;163;175m"    # Slate Gray
W = "\033[38;2;249;250;251m"    # Crisp White
RD = "\033[38;2;239;68;68m"     # Coral Red
R = "\033[0m"                   # Reset

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
]

joiner_lock = threading.Lock()
joiner_stats = {
    "joined": 0,
    "already_joined": 0,
    "failed": 0,
    "invalid": 0,
    "locked": 0,
    "rate_limited": 0,
    "total": 0
}


def _censor(token: str) -> str:
    token = token.strip()
    if len(token) > 24:
        return f"{token[:6]}...{token[-4:]}"
    return token[:10] + "..." if len(token) > 10 else token


def build_properties(user_agent: str) -> str:
    version = "124"
    m = re.search(r"Chrome/(\d+)", user_agent)
    if m:
        version = m.group(1)
    props = {
        "os": "Windows",
        "browser": "Chrome",
        "device": "",
        "system_locale": "en-US",
        "browser_user_agent": user_agent,
        "browser_version": f"{version}.0.0.0",
        "os_version": "10",
        "referrer": "",
        "referring_domain": "",
        "referrer_current": "",
        "referring_domain_current": "",
        "release_channel": "stable",
        "client_build_number": 335299,
        "client_event_source": None,
    }
    return base64.b64encode(json.dumps(props, separators=(",", ":")).encode()).decode()


def load_config():
    cfg_path = os.path.join(PROJECT_ROOT, "config.json")
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_config(cfg):
    cfg_path = os.path.join(PROJECT_ROOT, "config.json")
    try:
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=4)
        return True
    except Exception:
        return False


def load_tokens():
    candidates = [
        os.path.join(PROJECT_ROOT, "input", "tokens.txt"),
        os.path.join(PROJECT_ROOT, "output", "email_verified.txt"),
        os.path.join(PROJECT_ROOT, "output", "tokens.txt"),
    ]
    tokens = []
    seen = set()
    for path in candidates:
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    line = line.strip().strip('"').strip("'")
                    if not line:
                        continue
                    parts = line.split(":")
                    if len(parts) >= 3:
                        tk = parts[2]
                    else:
                        tk = line
                    tk = tk.strip()
                    if tk and tk not in seen and len(tk) >= 20:
                        seen.add(tk)
                        tokens.append(tk)
        except Exception:
            pass
        if tokens:
            break
    return tokens


def load_proxies(cfg=None):
    if cfg is not None:
        if cfg.get("use_proxy") is False or cfg.get("auth_joiner", {}).get("use_proxy") is False:
            return []
    proxy_path = os.path.join(PROJECT_ROOT, "input", "proxies.txt")
    proxies = []
    if os.path.exists(proxy_path):
        try:
            with open(proxy_path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    p = line.strip()
                    if p:
                        proxies.append(p)
        except Exception:
            pass
    return proxies


def format_proxy(proxy_str: str) -> str | None:
    if not proxy_str:
        return None
    p = proxy_str.strip()
    if not p.startswith("http://") and not p.startswith("https://") and not p.startswith("socks5://"):
        if "@" in p:
            p = f"http://{p}"
        else:
            parts = p.split(":")
            if len(parts) == 4:
                p = f"http://{parts[0]}:{parts[1]}@{parts[2]}:{parts[3]}"
            else:
                p = f"http://{p}"
    return p


def extract_user_id(token: str) -> str | None:
    try:
        part = token.split(".")[0]
        padded = part + "=" * (-len(part) % 4)
        uid_bytes = base64.urlsafe_b64decode(padded)
        uid_str = uid_bytes.decode("utf-8", errors="ignore")
        if uid_str.isdigit() and 16 <= len(uid_str) <= 22:
            return uid_str
    except Exception:
        pass
    return None


def fetch_user_id_api(token: str, proxy: str | None = None) -> str | None:
    p = format_proxy(proxy)
    try:
        s = curl_requests.Session(
            proxies={"http": p, "https": p} if p else None,
            impersonate="chrome124",
            timeout=8,
        )
        r = s.get("https://discord.com/api/v9/users/@me", headers={"Authorization": token})
        if r.status_code == 200:
            return str(r.json().get("id"))
    except Exception:
        pass
    return None


def resolve_invite_to_guild(invite_input: str) -> tuple[str | None, str | None]:
    """Resolves an invite code or URL to (guild_id, guild_name)."""
    code = invite_input.strip()
    for prefix in [
        "https://discord.gg/", "http://discord.gg/", "discord.gg/",
        "https://discord.com/invite/", "http://discord.com/invite/"
    ]:
        if code.startswith(prefix):
            code = code[len(prefix):]
            break
    code = code.split("/")[0].split("?")[0].strip()
    if not code:
        return None, None

    try:
        r = curl_requests.get(
            f"https://discord.com/api/v9/invites/{code}?with_counts=true",
            impersonate="chrome124",
            timeout=8
        )
        if r.status_code == 200:
            data = r.json()
            guild = data.get("guild", {})
            return str(guild.get("id")) if guild.get("id") else None, guild.get("name")
    except Exception:
        pass
    return None, None


def validate_bot_and_guild(bot_token: str, guild_id: str, client_id: str):
    """
    Проверяет валидность токена бота Discord и его присутствие на сервере.
    Возвращает (успех, сообщение_об_ошибке_или_OK).
    """
    print(f"  {D}│{R} Validating bot credentials and guild...")
    try:
        headers = {
            "Authorization": f"Bot {bot_token}",
            "User-Agent": "DiscordBot (https://discord.com, 1.0.0)"
        }
        bot_res = requests.get("https://discord.com/api/v9/users/@me", headers=headers, timeout=10)
        if bot_res.status_code != 200:
            return False, f"Invalid bot token! Discord returned HTTP {bot_res.status_code}"
        bot_data = bot_res.json()
        bot_tag = f"{bot_data.get('username')}#{bot_data.get('discriminator', '0000')}"
        print(f"  {D}│{R} {G}✓{R} Bot Authorized: {W}{bot_tag}{R} (ID: {bot_data.get('id')})")

        if guild_id:
            guild_res = requests.get(f"https://discord.com/api/v9/guilds/{guild_id}", headers=headers, timeout=10)
            if guild_res.status_code == 200:
                g_data = guild_res.json()
                print(f"  {D}│{R} {G}✓{R} Target Guild: {W}{g_data.get('name')}{R} (ID: {guild_id})")
                return True, "OK"
            elif guild_res.status_code == 404:
                invite_url = (
                    f"https://discord.com/oauth2/authorize?client_id={client_id}"
                    f"&permissions=8&scope=bot%20applications.commands"
                )
                print(f"  {D}│{R} {Y}⚠{R} Bot is NOT in guild {guild_id}!")
                print(f"  {D}│{R} {C}› Invite bot with this link:{R}\n  {W}{invite_url}{R}\n")
                return False, f"Bot is not in target guild (ID: {guild_id})"
            elif guild_res.status_code == 403:
                return False, f"Bot lacks permissions to view guild {guild_id}"
        return True, "OK"
    except Exception as e:
        return False, f"Bot verification error: {e}"


def save_result(token: str, category: str):
    out_dir = os.path.join(PROJECT_ROOT, "output", "joiner")
    os.makedirs(out_dir, exist_ok=True)
    filename = {
        "joined": "joined.txt",
        "already_joined": "already_joined.txt",
        "failed": "failed.txt",
        "invalid": "invalid.txt",
        "locked": "locked.txt",
    }.get(category, "other.txt")

    try:
        with open(os.path.join(out_dir, filename), "a", encoding="utf-8") as f:
            f.write(f"{token}\n")
    except Exception:
        pass


def join_single_token(token: str, client_id: str, client_secret: str, bot_token: str, guild_id: str, redirect_uri: str, proxy: str | None = None) -> str:
    global joiner_stats
    p = format_proxy(proxy)
    user_agent = random.choice(USER_AGENTS)
    short_tk = _censor(token)

    session = curl_requests.Session(
        proxies={"http": p, "https": p} if p else None,
        impersonate="chrome124",
        timeout=20,
    )

    # 1. Fast local Snowflake UID resolution
    user_id = extract_user_id(token)
    if not user_id:
        user_id = fetch_user_id_api(token, proxy)
    if not user_id:
        with joiner_lock:
            joiner_stats["invalid"] += 1
        print(f"  {RD}✗{R} {short_tk} → {RD}Invalid Token (Could not resolve User ID){R}")
        save_result(token, "invalid")
        return "invalid"

    # 2. Authorize via OAuth2
    encoded_redirect = quote(redirect_uri, safe="")
    auth_url = (
        f"https://discord.com/api/v9/oauth2/authorize"
        f"?client_id={client_id}"
        f"&response_type=code"
        f"&scope=identify%20guilds.join"
        f"&redirect_uri={encoded_redirect}"
    )

    headers = {
        "authority": "discord.com",
        "accept": "*/*",
        "accept-language": "en-US",
        "authorization": token,
        "content-type": "application/json",
        "origin": "https://discord.com",
        "referer": f"https://discord.com/oauth2/authorize?client_id={client_id}&response_type=code&scope=identify%20guilds.join&redirect_uri={encoded_redirect}",
        "sec-ch-ua": '"Not/A)Brand";v="8", "Chromium";v="124", "Google Chrome";v="124"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": user_agent,
        "x-super-properties": build_properties(user_agent),
    }

    code = None
    for attempt in range(2):
        try:
            resp = session.post(
                auth_url,
                json={"permissions": "0", "authorize": True},
                headers=headers,
                timeout=15,
            )

            if resp.status_code == 429:
                retry_after = 2.0
                try:
                    retry_after = float(resp.json().get("retry_after", 2.0))
                except Exception:
                    pass
                time.sleep(min(retry_after, 4.0))
                continue

            if resp.status_code == 401:
                with joiner_lock:
                    joiner_stats["invalid"] += 1
                print(f"  {RD}✗{R} {short_tk} → {RD}Invalid Token (401 Unauthorized){R}")
                save_result(token, "invalid")
                return "invalid"

            if resp.status_code == 403 or "verify your account" in resp.text or "40002" in resp.text:
                with joiner_lock:
                    joiner_stats["locked"] += 1
                print(f"  {Y}⚠{R} {short_tk} → {Y}Locked / Phone Verification Required{R}")
                save_result(token, "locked")
                return "locked"

            if resp.status_code == 400:
                resp_text = resp.text
                if "Invalid OAuth2 redirect_uri" in resp_text:
                    print(f"  {RD}✗{R} {short_tk} → {RD}Invalid Redirect URI! Add '{redirect_uri}' to Discord Developer Portal!{R}")
                    with joiner_lock:
                        joiner_stats["failed"] += 1
                    save_result(token, "failed")
                    return "failed"
                else:
                    print(f"  {RD}✗{R} {short_tk} → {RD}Authorize 400 Bad Request: {resp_text[:80]}{R}")
                    with joiner_lock:
                        joiner_stats["failed"] += 1
                    save_result(token, "failed")
                    return "failed"

            if resp.status_code in (200, 201):
                try:
                    data = resp.json()
                    loc = data.get("location", "")
                    if "code=" in loc:
                        parsed = urlparse(loc)
                        qs = parse_qs(parsed.query)
                        code = qs.get("code", [None])[0]
                        if not code:
                            m = re.search(r"[?&]code=([a-zA-Z0-9_-]+)", loc)
                            if m:
                                code = m.group(1)
                        if code:
                            break
                except Exception:
                    pass

        except Exception as e:
            if attempt == 1:
                print(f"  {RD}✗{R} {short_tk} → {RD}Connection error: {e}{R}")
                with joiner_lock:
                    joiner_stats["failed"] += 1
                save_result(token, "failed")
                return "failed"
            time.sleep(0.5)

    if not code:
        with joiner_lock:
            joiner_stats["failed"] += 1
        print(f"  {RD}✗{R} {short_tk} → {RD}Failed to retrieve OAuth2 code{R}")
        save_result(token, "failed")
        return "failed"

    # 3. Exchange code for Access Token
    access_token = None
    try:
        token_exchange = requests.post(
            "https://discord.com/api/v9/oauth2/token",
            data={
                "client_id": client_id,
                "client_secret": client_secret,
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": redirect_uri,
            },
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": "DiscordBot (https://discord.com, 1.0.0)",
            },
            timeout=12,
        )
        if token_exchange.status_code == 200:
            access_token = token_exchange.json().get("access_token")
        else:
            print(f"  {RD}✗{R} {short_tk} → {RD}Token exchange failed (HTTP {token_exchange.status_code}): {token_exchange.text[:80]}{R}")
            with joiner_lock:
                joiner_stats["failed"] += 1
            save_result(token, "failed")
            return "failed"
    except Exception as e:
        print(f"  {RD}✗{R} {short_tk} → {RD}Exchange exception: {e}{R}")
        with joiner_lock:
            joiner_stats["failed"] += 1
        save_result(token, "failed")
        return "failed"

    if not access_token:
        with joiner_lock:
            joiner_stats["failed"] += 1
        return "failed"

    # 4. Bot adds Member to Guild
    join_url = f"https://discord.com/api/v9/guilds/{guild_id}/members/{user_id}"
    bot_headers = {
        "Authorization": f"Bot {bot_token}",
        "Content-Type": "application/json",
        "User-Agent": "DiscordBot (https://discord.com, 1.0.0)",
    }

    try:
        join_resp = requests.put(
            join_url,
            json={"access_token": access_token},
            headers=bot_headers,
            timeout=12,
        )

        if join_resp.status_code == 201:
            with joiner_lock:
                joiner_stats["joined"] += 1
            print(f"  {G}✓{R} {short_tk} → {G}Successfully Joined Guild!{R}")
            save_result(token, "joined")
            return "joined"

        elif join_resp.status_code == 204:
            with joiner_lock:
                joiner_stats["already_joined"] += 1
            print(f"  {C}ℹ{R} {short_tk} → {C}Already a Member of Guild{R}")
            save_result(token, "already_joined")
            return "already_joined"

        elif join_resp.status_code == 400:
            body = {}
            try:
                body = join_resp.json()
            except Exception:
                pass
            if body.get("code") == 30001:
                with joiner_lock:
                    joiner_stats["failed"] += 1
                print(f"  {Y}⚠{R} {short_tk} → {Y}Max Guilds Reached (100 servers limit){R}")
                save_result(token, "failed")
                return "failed"
            else:
                with joiner_lock:
                    joiner_stats["failed"] += 1
                print(f"  {RD}✗{R} {short_tk} → {RD}Join 400: {join_resp.text[:80]}{R}")
                save_result(token, "failed")
                return "failed"

        elif join_resp.status_code == 403:
            with joiner_lock:
                joiner_stats["failed"] += 1
            print(f"  {RD}✗{R} {short_tk} → {RD}Bot Forbidden (403)! Ensure bot has 'Create Instant Invite' and role is positioned high.{R}")
            save_result(token, "failed")
            return "failed"

        elif join_resp.status_code == 429:
            with joiner_lock:
                joiner_stats["rate_limited"] += 1
            print(f"  {Y}⚠{R} {short_tk} → {Y}Guild Member Add Rate Limited{R}")
            save_result(token, "failed")
            return "failed"

        else:
            with joiner_lock:
                joiner_stats["failed"] += 1
            print(f"  {RD}✗{R} {short_tk} → {RD}Join failed (HTTP {join_resp.status_code}): {join_resp.text[:80]}{R}")
            save_result(token, "failed")
            return "failed"

    except Exception as e:
        with joiner_lock:
            joiner_stats["failed"] += 1
        print(f"  {RD}✗{R} {short_tk} → {RD}Member add exception: {e}{R}")
        save_result(token, "failed")
        return "failed"


def print_gui_stat(total: int):
    if os.environ.get("GUI_MODE") == "1":
        with joiner_lock:
            j = joiner_stats["joined"] + joiner_stats["already_joined"]
            f = joiner_stats["failed"]
            inv = joiner_stats["invalid"]
            lock = joiner_stats["locked"]
            print(f"GUI_STAT:{j},0,0,{f},{lock},{inv},{total}", flush=True)


def main():
    cfg = load_config()
    aj_cfg = cfg.get("auth_joiner") or cfg.get("joiner", {})
    bot_cfg = aj_cfg.get("bot", {})
    web_cfg = aj_cfg.get("web", {})
    data_cfg = aj_cfg.get("data", {})

    client_id = bot_cfg.get("id") or aj_cfg.get("client_id") or cfg.get("client_id", "")
    client_secret = bot_cfg.get("secret") or aj_cfg.get("client_secret") or cfg.get("client_secret", "")
    bot_token = bot_cfg.get("token") or aj_cfg.get("bot_token") or cfg.get("bot_token", "")
    guild_id = data_cfg.get("guildId") or aj_cfg.get("guild_id") or cfg.get("guild_id", "")
    invite_cfg = data_cfg.get("invite") or aj_cfg.get("invite") or cfg.get("invite", "")
    redirect_uri = web_cfg.get("url") or aj_cfg.get("redirect_uri") or "http://localhost:8080/"

    # Parse CLI overrides (--gui-guild or --gui-invite)
    if "--gui-guild" in sys.argv:
        try:
            idx = sys.argv.index("--gui-guild")
            if len(sys.argv) > idx + 1:
                guild_id = sys.argv[idx + 1].strip()
        except Exception:
            pass

    if "--gui-invite" in sys.argv:
        try:
            idx = sys.argv.index("--gui-invite")
            if len(sys.argv) > idx + 1:
                invite_cfg = sys.argv[idx + 1].strip()
        except Exception:
            pass

    # Заголовочный баннер (Header Banner)
    print(f"\n  {P}┌──────────────────────────────────────────┐{R}")
    print(f"  {P}│{R}    {C}Lord Vault High-Speed Token Joiner{R}    {P}│{R}")
    print(f"  {P}└──────────────────────────────────────────┘{R}\n")

    is_gui = os.environ.get("GUI_MODE") == "1"

    # Получение client_id из токена бота, если не указан напрямую
    if not client_id and bot_token:
        try:
            extracted_bid = extract_user_id(bot_token)
            if extracted_bid:
                client_id = extracted_bid
        except Exception:
            pass

    # Проверка учетных данных OAuth2 бота
    if not client_id or not client_secret or not bot_token:
        if is_gui:
            print(f"  {RD}[!] Error: Missing OAuth2 bot credentials in config.json!{R}")
            print(f"  {Y}    Please configure Client ID, Secret, and Bot Token in settings.{R}")
            sys.exit(1)
        else:
            print(f"  {Y}⚠ Bot OAuth2 credentials need to be configured in config.json:{R}\n")
            if not client_id:
                client_id = input(f"  {P}›{R} Enter Bot Client ID: ").strip()
            if not client_secret:
                client_secret = input(f"  {P}›{R} Enter Bot Client Secret: ").strip()
            if not bot_token:
                bot_token = input(f"  {P}›{R} Enter Bot Token: ").strip()

            if not client_id or not client_secret or not bot_token:
                print(f"\n  {RD}✗ Missing required bot credentials! Exiting...{R}")
                return

    # Разрешение Guild ID или кода приглашения (Invite resolution)
    target_name = None
    # 1. Если передана ссылка-приглашение, резолвим ID сервера
    if invite_cfg and not guild_id:
        print(f"  {D}│{R} Resolving guild from invite '{invite_cfg}'...")
        res_gid, res_name = resolve_invite_to_guild(invite_cfg)
        if res_gid:
            guild_id = res_gid
            target_name = res_name
            print(f"  {D}│{R} {G}✓{R} Resolved Guild: {W}{target_name}{R} (Guild ID: {guild_id})")
        else:
            print(f"  {D}│{R} {Y}⚠{R} Could not resolve Guild ID from invite; please verify.")

    # 2. Интерактивный запрос, если ID гильдии всё еще не указан
    if not guild_id:
        if is_gui:
            print(f"  {RD}[!] Error: No Guild ID or Invite URL provided!{R}")
            sys.exit(1)
        else:
            raw_input_val = input(f"  {P}›{R} Enter Target Guild ID or Invite URL/code: ").strip()
            if not raw_input_val:
                print(f"\n  {RD}✗ No Guild ID or invite provided! Exiting...{R}")
                return
            # Проверка, введен инвайт или чистый ID
            if any(raw_input_val.startswith(p) for p in ["http", "discord.gg"]) or not raw_input_val.isdigit():
                print(f"  {D}│{R} Resolving invite '{raw_input_val}'...")
                res_gid, res_name = resolve_invite_to_guild(raw_input_val)
                if res_gid:
                    guild_id = res_gid
                    target_name = res_name
                    print(f"  {D}│{R} {G}✓{R} Resolved Guild: {W}{target_name}{R} (Guild ID: {guild_id})")
                else:
                    print(f"  {RD}✗ Invalid invite link or code!{R}")
                    return
            else:
                guild_id = raw_input_val

            # Запрос сохранения в конфигурационный файл
            save_q = input(f"\n  {C}› Save target guild to config.json? [Y/n]: {R}").strip().lower()
            if save_q in ("", "y", "yes"):
                if "auth_joiner" not in cfg:
                    cfg["auth_joiner"] = {}
                if "data" not in cfg["auth_joiner"]:
                    cfg["auth_joiner"]["data"] = {}
                cfg["auth_joiner"]["data"]["guildId"] = guild_id
                save_config(cfg)
                print(f"  {G}✓ Target Guild saved to config.json!{R}\n")

    # Загрузка токенов и прокси
    tokens = load_tokens()
    proxies = load_proxies(cfg)

    if not tokens:
        print(f"  {RD}✗ No tokens found in input/tokens.txt or output/email_verified.txt!{R}")
        print(f"  {D}  Please add tokens to proceed.{R}")
        return

    # Предварительная валидация бота
    valid, msg = validate_bot_and_guild(bot_token, guild_id, client_id)
    if not valid:
        print(f"\n  {RD}✗ Pre-flight check failed: {msg}{R}")
        if is_gui:
            sys.exit(1)
        cont = input(f"\n  {Y}Continue anyway? [y/N]: {R}").strip().lower()
        if cont not in ("y", "yes"):
            return

    # Настройка многопоточности
    max_cfg_threads = cfg.get("threading", {}).get("joiner", 100)
    thread_count = min(max_cfg_threads, len(tokens))

    print(f"\n  {P}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{R}")
    print(f"  {D}│{R} Target Guild: {W}{guild_id}{f' ({target_name})' if target_name else ''}{R}")
    print(f"  {D}│{R} Tokens:       {W}{len(tokens)}{R}")
    print(f"  {D}│{R} Proxies:      {W}{len(proxies)} loaded{' (Direct / No Proxy)' if not proxies else ''}{R}")
    print(f"  {D}│{R} Threads:      {W}{thread_count} (Turbo Mode){R}")
    print(f"  {D}│{R} Redirect URI: {W}{redirect_uri}{R}")
    print(f"  {P}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{R}\n")

    start_time = time.time()
    total_tokens = len(tokens)
    joiner_stats["total"] = total_tokens
    print_gui_stat(total_tokens)

    # Функция-воркер для одного токена
    def worker(tk):
        proxy = random.choice(proxies) if proxies else None
        res = join_single_token(
            token=tk,
            client_id=client_id,
            client_secret=client_secret,
            bot_token=bot_token,
            guild_id=guild_id,
            redirect_uri=redirect_uri,
            proxy=proxy,
        )
        print_gui_stat(total_tokens)
        return res

    # Параллельный запуск пула потоков
    with ThreadPoolExecutor(max_workers=thread_count) as executor:
        futures = [executor.submit(worker, tk) for tk in tokens]
        for f in as_completed(futures):
            pass

    elapsed = time.time() - start_time
    print_gui_stat(total_tokens)

    # Итоговая статистика выполнения
    print(f"\n  {P}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{R}")
    print(f"  {G}✓ Joined Server:   {joiner_stats['joined']}{R}")
    print(f"  {C}ℹ Already Member:  {joiner_stats['already_joined']}{R}")
    print(f"  {RD}✗ Failed:          {joiner_stats['failed']}{R}")
    print(f"  {RD}⊘ Invalid Tokens:  {joiner_stats['invalid']}{R}")
    print(f"  {Y}⚠ Locked Tokens:   {joiner_stats['locked']}{R}")
    print(f"  {D}  Elapsed Time:    {elapsed:.1f}s{R}")
    print(f"  {P}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{R}")
    print(f"  {G}✓ Results saved to output/joiner/{R}\n")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n  {Y}›› Joiner stopped by user.{R}\n")
    if os.environ.get("GUI_MODE") != "1" and "--gui-guild" not in sys.argv and "--gui-invite" not in sys.argv:
        input(f"  {Y}Press Enter to return...{R}")
