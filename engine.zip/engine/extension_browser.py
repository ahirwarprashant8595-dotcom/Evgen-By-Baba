import asyncio
import base64
import json
import os
import re
import threading
import time
import random
import shutil
import tempfile
from pathlib import Path
from typing import Optional, Dict

import nodriver as uc
import tls_client

BROWSER_WIDTH  = 400
BROWSER_HEIGHT = 500
MAX_CONCURRENT = 3
TASK_TIMEOUT   = 120

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)
NOPECHA_EXT_DIR = os.path.join(PROJECT_ROOT, "nopecha_ext")
EXTENSION_DIR = NOPECHA_EXT_DIR if os.path.exists(NOPECHA_EXT_DIR) else os.path.join(PROJECT_ROOT, "extension")
EXT_CONFIG_FILE = os.path.join(EXTENSION_DIR, "nopecha_config.json")
CONFIG_FILE = os.path.join(PROJECT_ROOT, "config.json")

def get_brave_path() -> Optional[str]:
    paths = [
        r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
        r"C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\BraveSoftware\Brave-Browser\Application\brave.exe"),
        "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
        "/usr/bin/brave-browser",
        "/usr/bin/brave",
        "/snap/bin/brave",
    ]
    for p in paths:
        if os.path.exists(p):
            return p
    return None

BRAVE_PATH = get_brave_path()

def _load_config():
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def inject_nopecha_key(api_key: str) -> bool:
    if not api_key:
        return False
    dirs_to_inject = []
    for d in [os.path.join(PROJECT_ROOT, "nopecha_ext"), os.path.join(PROJECT_ROOT, "extension")]:
        if os.path.exists(d):
            dirs_to_inject.append(Path(d))
    if not dirs_to_inject:
        return False

    for ext_dir in dirs_to_inject:
        try:
            # Method 1: Add to manifest.json
            manifest_path = ext_dir / "manifest.json"
            if manifest_path.exists():
                with open(manifest_path, "r", encoding="utf-8") as f:
                    manifest = json.load(f)
                if "nopecha" not in manifest:
                    manifest["nopecha"] = {}
                manifest["nopecha"]["key"] = api_key
                with open(manifest_path, "w", encoding="utf-8") as f:
                    json.dump(manifest, f, indent=2)

            # Method 2: Create storage initialization script
            storage_init_path = ext_dir / "storage_init.js"
            storage_init_code = f"""// Auto-generated storage initialization for NopeCHA extension
(function() {{
  const nopecha_api_key = '{api_key}';
  chrome.storage.local.set({{'nopecha_key': nopecha_api_key}}, function() {{
    console.log('[NopeCHA Storage] API Key initialized');
  }});
}})();
"""
            with open(storage_init_path, "w", encoding="utf-8") as f:
                f.write(storage_init_code)

            # Method 3: Create nopecha_config.json file
            config_path = ext_dir / "nopecha_config.json"
            config_data = {
                "api_key": api_key,
                "enabled": True,
                "timestamp": time.time()
            }
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(config_data, f, indent=2)
        except Exception as e:
            print(f"  [EXT] ⚠ Warning injecting NopeCHA key into {ext_dir}: {e}")
    return True

def sync_api_key():
    config = _load_config()
    nopecha_cfg = config.get("nopecha") or config.get("solver", {})
    api_key = nopecha_cfg.get("api_key", "").strip()
    if not api_key:
        api_key = config.get("solver", {}).get("api_key", "").strip()
    if not api_key:
        print("  [EXT] No NopeCHA API key found in config.json under nopecha.api_key")
        return False
    try:
        import requests
        resp = requests.get(
            f"https://api.nopecha.com/status?key={api_key}",
            timeout=15
        )
        if resp.status_code == 401:
            print("  [EXT] ✗ Key validation failed: Invalid NopeCHA API key")
            return False
        if resp.status_code >= 500:
            print(f"  [EXT] ✗ Key validation failed: NopeCHA server returned {resp.status_code}")
            return "SERVER_ERROR"
        data = resp.json()
        if "error" in data:
            print(f"  [EXT] ✗ Key validation failed: {data.get('message', 'Invalid key')}")
            return False

        inject_nopecha_key(api_key)
        return api_key
    except requests.exceptions.RequestException as e:
        print(f"  [EXT] ⚠ Note: Network warning during key check: {e}")
        inject_nopecha_key(api_key)
        return api_key
    except Exception as e:
        print(f"  [EXT] ✗ Key validation error: {e}")
        return "SERVER_ERROR"

def parse_proxy(proxy_string: str) -> Optional[dict]:
    if not proxy_string:
        return None
    try:
        raw = proxy_string.strip()
        scheme = "http"
        if "://" in raw:
            scheme, raw = raw.split("://", 1)
        host, port = None, None
        username, password = None, None
        if "@" in raw:
            creds, addr = raw.split("@", 1)
            if ":" in creds:
                username, password = creds.split(":", 1)
            if ":" in addr:
                host, port = addr.split(":", 1)
                port = int(port.split("/")[0])
        elif ":" in raw:
            tokens = raw.split(":")
            if len(tokens) == 2:
                host, port = tokens[0], int(tokens[1].split("/")[0])
            elif len(tokens) == 4:
                if tokens[1].isdigit():
                    host, port = tokens[0], int(tokens[1])
                    username, password = tokens[2], tokens[3]
                elif tokens[3].isdigit():
                    username, password = tokens[0], tokens[1]
                    host, port = tokens[2], int(tokens[3])
        if not host or not port:
            return None
        if username and password:
            full_url = f"{scheme}://{username}:{password}@{host}:{port}"
            proxy_url_no_creds = f"{scheme}://{host}:{port}"
        else:
            full_url = f"{scheme}://{host}:{port}"
            proxy_url_no_creds = full_url
        return {
            'type': scheme,
            'host': host,
            'port': port,
            'username': username or "",
            'password': password or "",
            'full_url': full_url,
            'proxy_url_no_creds': proxy_url_no_creds,
        }
    except Exception:
        return None

def create_proxy_extension(proxy_config: dict, temp_profile: str) -> Optional[str]:
    if not proxy_config or not proxy_config.get('host') or not proxy_config.get('port'):
        return None
    host = proxy_config.get('host')
    port = proxy_config.get('port')
    username = proxy_config.get('username', '')
    password = proxy_config.get('password', '')
    if not username or not password:
        return None
    ext_dir = os.path.join(temp_profile, "proxy_auth_ext")
    os.makedirs(ext_dir, exist_ok=True)
    manifest_json = {
        "version": "1.0.0",
        "manifest_version": 2,
        "name": f"Proxy Auth {host}",
        "permissions": [
            "proxy",
            "tabs",
            "unlimitedStorage",
            "storage",
            "<all_urls>",
            "webRequest",
            "webRequestBlocking"
        ],
        "background": {
            "scripts": ["background.js"]
        },
        "minimum_chrome_version": "22.0.0"
    }
    background_js = f"""var config = {{
    mode: "fixed_servers",
    rules: {{
        singleProxy: {{
            scheme: "http",
            host: "{host}",
            port: parseInt({port})
        }},
        bypassList: ["localhost", "127.0.0.1"]
    }}
}};
chrome.proxy.settings.set({{value: config, scope: "regular"}}, function() {{}});
function callbackFn(details) {{
    return {{
        authCredentials: {{
            username: "{username}",
            password: "{password}"
        }}
    }};
}}
chrome.webRequest.onAuthRequired.addListener(
    callbackFn,
    {{urls: ["<all_urls>"]}},
    ['blocking']
);
"""
    try:
        with open(os.path.join(ext_dir, "manifest.json"), "w", encoding="utf-8") as f:
            json.dump(manifest_json, f, indent=2)
        with open(os.path.join(ext_dir, "background.js"), "w", encoding="utf-8") as f:
            f.write(background_js)
        return ext_dir
    except Exception:
        return None

def get_browser_proxy_args(proxy_config: dict) -> list:
    args = []
    if not proxy_config:
        return args
    proxy_url = proxy_config.get('proxy_url_no_creds') or proxy_config.get('full_url')
    if proxy_url:
        args.append(f'--proxy-server={proxy_url}')
        args.append('--proxy-bypass-list=<-loopback>')
    return args

JS_UTILS = """(() => {
    if (window.utils) return;
    function setInput(selector, value) {
        const el = document.querySelector(selector);
        if (el) {
            el.value = value;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }
    function clickAllCheckboxes() {
        const checkboxes = document.querySelectorAll('input[type="checkbox"]');
        let clicked = 0;
        checkboxes.forEach(cb => {
            if (!cb.checked) {
                cb.click();
                cb.checked = true;
                clicked++;
            }
        });
        return { clicked: clicked, total: checkboxes.length };
    }
    window.utils = {
        setInput,
        clickAllCheckboxes,
    };
})();
"""

async def fill_date_of_birth(page):
    months = ["January", "February", "March", "April", "May", "June",
              "July", "August", "September", "October", "November", "December"]
    day = str(random.randint(1, 28))
    month = random.choice(months)
    year = str(random.randint(1998, 2004))
    try:
        await page.evaluate(f'''
        (async () => {{
            async function setDobField(label, value) {{
                const el = document.querySelector(`div[aria-label="${{label}}"]`);
                if (!el) return false;
                el.click();
                await new Promise(r => setTimeout(r, 100));
                for (let i = 0; i < value.length; i++) {{
                    const char = value[i];
                    document.activeElement.dispatchEvent(new KeyboardEvent('keydown', {{
                        key: char,
                        code: isNaN(char) ? 'Key' + char.toUpperCase() : 'Digit' + char,
                        keyCode: char.toUpperCase().charCodeAt(0),
                        bubbles: true
                    }}));
                    await new Promise(r => setTimeout(r, 50));
                }}
                await new Promise(r => setTimeout(r, 100));
                document.activeElement.dispatchEvent(new KeyboardEvent('keydown', {{
                    key: 'Enter',
                    code: 'Enter',
                    keyCode: 13,
                    bubbles: true
                }}));
                await new Promise(r => setTimeout(r, 100));
                return true;
            }}
            await setDobField("Month", "{month}");
            await setDobField("Day", "{day}");
            await setDobField("Year", "{year}");
            document.body.click();
            await new Promise(r => setTimeout(r, 150));
            const buttons = document.querySelectorAll('button');
            for (const btn of buttons) {{
                const text = btn.textContent || '';
                if (text.includes('Continue') || text.includes('Create') || text.includes('Submit') || text.includes('Register')) {{
                    btn.click();
                    break;
                }}
            }}
            return true;
        }})()
        ''')
    except Exception:
        pass

async def fill_registration_form(page, email: str, display_name: str, username: str, password: str, logger=None) -> bool:
    try:
        email_element = await page.wait_for('input[name="email"]', timeout=10000)
        await email_element.send_keys(email)
        await asyncio.sleep(0.1)

        display_element = await page.wait_for('input[name="global_name"]', timeout=5000)
        await display_element.send_keys(display_name)
        await asyncio.sleep(0.1)

        username_element = await page.wait_for('input[name="username"]', timeout=5000)
        await username_element.send_keys(username)
        await asyncio.sleep(0.1)

        password_element = None
        selectors = [
            'input[aria-label="Password"]',
            'input[name="password"]',
            'input[type="password"]'
        ]
        for selector in selectors:
            try:
                password_element = await page.query_selector(selector)
                if password_element:
                    break
            except Exception:
                continue

        if password_element:
            await password_element.send_keys(password)
            await asyncio.sleep(0.2)

        await asyncio.sleep(0.2)
        await fill_date_of_birth(page)
        await asyncio.sleep(0.1)

        try:
            await page.evaluate(JS_UTILS)
            await asyncio.sleep(0.1)
            await page.evaluate('window.utils.clickAllCheckboxes()')
        except Exception:
            pass

        clicked = False
        await asyncio.sleep(0.3)
        try:
            buttons = await page.query_selector_all('button')
            for button in buttons:
                try:
                    text = await button.get('textContent') or ""
                    if text and any(k in text for k in ['Continue', 'Create', 'Submit', 'Register']):
                        await button.click()
                        clicked = True
                        break
                except Exception:
                    continue
        except Exception:
            pass

        if not clicked:
            try:
                submit = await page.query_selector('[type="submit"]')
                if submit:
                    await submit.click()
                    clicked = True
            except Exception:
                pass

        if not clicked:
            try:
                clicked = await page.evaluate('''() => {
                    const buttons = document.querySelectorAll('button');
                    for (const btn of buttons) {
                        const text = btn.textContent || '';
                        if (text.includes('Continue') || text.includes('Create') || text.includes('Submit')) {
                            btn.click();
                            return true;
                        }
                    }
                    return false;
                }''')
            except Exception:
                pass

        # Check if Discord flags the username as taken/unavailable and auto-recover
        curr_user = username
        for retry in range(5):
            await asyncio.sleep(0.7)
            # If navigation already occurred (out of register page), success!
            try:
                u_check = await page.evaluate('window.location.href')
                u_val = u_check.value if hasattr(u_check, 'value') else (str(u_check[0]) if isinstance(u_check, tuple) else str(u_check or ''))
                if u_val and 'discord.com/register' not in u_val:
                    return True
            except Exception:
                pass

            is_unavailable = await page.evaluate('''() => {
                const bodyText = (document.body.innerText || '').toLowerCase();
                if (bodyText.includes('username is unavailable') || bodyText.includes('try adding numbers')) {
                    return true;
                }
                const errs = document.querySelectorAll('[class*="errorMessage"], [class*="error"], [role="alert"]');
                for (const el of errs) {
                    const t = (el.innerText || '').toLowerCase();
                    if (t.includes('unavailable') || t.includes('numbers, letters, underscores')) return true;
                }
                return false;
            }''')

            if not is_unavailable:
                break

            # Discord rejected the username: generate a fresh unique username and update input
            rand_suffix = f"{random.randint(100, 999)}{random.choice('abcdefghjkmnpqrstuvwxyz')}{random.randint(10, 99)}"
            base_clean = re.sub(r'[^a-zA-Z0-9_.]', '', curr_user)[:16]
            curr_user = f"{base_clean}_{rand_suffix}".lower()
            if logger:
                logger(f"Username taken, auto-updating to: {curr_user}")

            await page.evaluate(f'''() => {{
                const input = document.querySelector('input[name="username"]');
                if (input) {{
                    input.focus();
                    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
                    setter.call(input, "{curr_user}");
                    input.dispatchEvent(new Event('input', {{ bubbles: true }}));
                    input.dispatchEvent(new Event('change', {{ bubbles: true }}));
                }}
            }}''')
            await asyncio.sleep(0.4)

            # Re-submit
            await page.evaluate('''() => {
                const buttons = document.querySelectorAll('button');
                for (const btn of buttons) {
                    const text = (btn.textContent || '').toLowerCase();
                    if (text.includes('continue') || text.includes('create') || text.includes('submit')) {
                        btn.click();
                        return true;
                    }
                }
                const sub = document.querySelector('[type="submit"]');
                if (sub) { sub.click(); return true; }
                return false;
            }''')

        return bool(clicked)
    except Exception:
        return False

DISCORD_TOKEN_REGEX = re.compile(r'([a-zA-Z0-9_-]{20,}\.[a-zA-Z0-9_-]{4,10}\.[a-zA-Z0-9_-]{25,})')

def validate_discord_token(raw) -> Optional[str]:
    """Validate that a string is a real Discord token.
    
    A Discord token has three base64 segments separated by dots:
    1. Base64-encoded user ID (must decode to a pure numeric string)
    2. Base64-encoded timestamp  
    3. HMAC signature
    
    Rejects ExceptionDetails strings, quoted localStorage values, and
    any string whose first segment doesn't decode to a valid numeric user ID.
    """
    if not raw:
        return None
    if not isinstance(raw, str):
        if hasattr(raw, 'value') and isinstance(raw.value, str):
            raw = raw.value
        elif isinstance(raw, (list, tuple)) and raw and isinstance(raw[0], str):
            raw = raw[0]
        else:
            return None
    if any(err in raw for err in ["ExceptionDetails", "Uncaught", "ReferenceError", "TypeError", "SyntaxError"]):
        return None
    raw = raw.strip().strip('"').strip("'")
    m = DISCORD_TOKEN_REGEX.search(raw)
    if m:
        candidate = m.group(1)
        # Verify the first segment is a valid base64-encoded numeric user ID
        first_part = candidate.split('.')[0]
        try:
            # Add padding for base64
            padded = first_part + '=' * (-len(first_part) % 4)
            decoded = base64.b64decode(padded).decode('utf-8', errors='ignore')
            # Discord user IDs are pure numeric snowflake IDs (e.g. "1340112345678901234")
            if decoded.isdigit() and len(decoded) >= 15:
                return candidate
        except Exception:
            pass
    return None

EXTRACT_TOKEN_JS = """(() => {
    try {
        let t = window.localStorage.getItem('token');
        if (t) return t.replace(/^"|"$/g, '');
        try {
            let iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            document.body.appendChild(iframe);
            t = iframe.contentWindow.localStorage.getItem('token');
            iframe.remove();
            if (t) return t.replace(/^"|"$/g, '');
        } catch(e) {}
    } catch(e) {}
    return '';
})()"""

async def get_token_from_cdp_storage(page) -> Optional[str]:
    """Read the 'token' key from Discord's localStorage via CDP."""
    try:
        from nodriver.cdp import dom_storage
        sid = dom_storage.StorageId(security_origin='https://discord.com', is_local_storage=True)
        items = await page.send(dom_storage.get_dom_storage_items(storage_id=sid))
        if items:
            for item in items:
                if len(item) >= 2 and item[0] == 'token':
                    v = item[1].strip('"')
                    valid = validate_discord_token(v)
                    if valid:
                        return valid
    except Exception:
        pass
    return None

async def get_token_from_page_eval(page) -> Optional[str]:
    try:
        res = await page.evaluate(EXTRACT_TOKEN_JS)
        if hasattr(res, 'value'):
            res = res.value
        return validate_discord_token(res)
    except Exception:
        return None

async def wait_for_account_creation(page, timeout: int = 300) -> tuple:
    """Wait for Discord to navigate away from /register after captcha is solved.
    
    IMPORTANT: This function ONLY checks URL changes. It does NOT check for tokens,
    because during captcha solving, localStorage may contain stale/garbage values
    that look like tokens but aren't (false positives that cause premature return).
    Token extraction happens separately in wait_for_discord_token().
    """
    start_time = time.time()
    last_url = ""

    while (time.time() - start_time) < timeout:
        await asyncio.sleep(0.5)
        try:
            current_url = ""
            try:
                raw_url = await page.evaluate('window.location.href')
                if hasattr(raw_url, 'value'):
                    current_url = raw_url.value or ""
                elif isinstance(raw_url, tuple):
                    current_url = str(raw_url[0]) if raw_url[0] else ""
                else:
                    current_url = str(raw_url) if raw_url else ""
            except Exception:
                current_url = ""

            if current_url and current_url != last_url:
                last_url = current_url

            if not current_url:
                continue

            skip = ['discord.com/register', 'discord.com/login', 'about:blank', 'chrome://']
            if 'discord.com' in current_url and not any(s in current_url for s in skip):
                solve_time = max(0.1, round(time.time() - start_time, 1))
                return True, solve_time
        except Exception:
            pass

    return False, 0.0

async def fetch_discord_token(email: str, password: str, proxy_config: dict = None) -> Optional[str]:
    url = "https://discord.com/api/v9/auth/login"
    headers = {
        "accept": "*/*",
        "content-type": "application/json",
        "origin": "https://discord.com",
        "referer": "https://discord.com/channels/@me",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    payload = {"login": email, "password": password}

    def _do_login():
        try:
            session = tls_client.Session(client_identifier="chrome_131", random_tls_extension_order=True)
            if proxy_config:
                full_url = proxy_config.get('full_url')
                if full_url:
                    session.proxies = {'http': full_url, 'https': full_url}
            response = session.post(url, headers=headers, json=payload, timeout_seconds=15)
            if response.status_code == 429:
                time.sleep(5)
                response = session.post(url, headers=headers, json=payload, timeout_seconds=15)
            if response.status_code == 200:
                return response.json().get("token", "")
            return ""
        except Exception:
            return ""

    try:
        raw_token = await asyncio.wait_for(
            asyncio.to_thread(_do_login),
            timeout=20
        )
        return validate_discord_token(raw_token)
    except Exception:
        return None

async def check_email_verified_api(token: str, proxy_config: dict = None) -> bool:
    if not token or not validate_discord_token(token):
        return False

    def _do_check():
        try:
            session = tls_client.Session(client_identifier="chrome_131")
            if proxy_config and proxy_config.get('full_url'):
                session.proxies = {'http': proxy_config['full_url'], 'https': proxy_config['full_url']}
            headers = {'Authorization': token}
            response = session.get('https://discord.com/api/v9/users/@me', headers=headers, timeout_seconds=12)
            if response.status_code == 200:
                return bool(response.json().get('verified', False))
            return False
        except Exception:
            return False

    try:
        return await asyncio.wait_for(
            asyncio.to_thread(_do_check),
            timeout=15
        )
    except Exception:
        return False

async def wait_for_discord_token(page, timeout: int = 30, email: str = None, password: str = None, proxy_config: dict = None) -> Optional[str]:
    # 1. Quick check if token is already in localStorage
    tok = await get_token_from_cdp_storage(page)
    if tok:
        return tok
    tok = await get_token_from_page_eval(page)
    if tok:
        return tok

    # 2. Try auth login (VoidMart term.py primary method)
    if email and password:
        await asyncio.sleep(2)
        for _ in range(5):
            tok = await fetch_discord_token(email, password, proxy_config)
            if tok:
                return tok
            tok = await get_token_from_cdp_storage(page)
            if tok:
                return tok
            await asyncio.sleep(2)

    # 3. Final storage check
    tok = await get_token_from_cdp_storage(page)
    if tok:
        return tok
    tok = await get_token_from_page_eval(page)
    if tok:
        return tok

    return None

async def verify_email_with_url(browser, verify_url: str, token: str = None, email: str = None, password: str = None, proxy_config: dict = None, timeout: int = 30) -> tuple[bool, Optional[str]]:
    if not verify_url:
        return False, token
    try:
        page = await browser.get(verify_url)
        await asyncio.sleep(3)

        # Click "Continue to Discord" / "Verify" button
        clicked = False
        for attempt in range(3):
            try:
                buttons = await page.query_selector_all('button')
                for btn in buttons:
                    try:
                        txt = await btn.get('textContent') or ""
                        if any(w in txt.lower() for w in ['continue', 'verify', 'open discord', 'open in discord']):
                            await btn.click()
                            clicked = True
                            await asyncio.sleep(3)
                            break
                    except Exception:
                        continue
                if clicked:
                    break
            except Exception:
                pass
            await asyncio.sleep(1)

        if not clicked:
            # Try JS click fallback
            try:
                await page.evaluate("""(() => {
                    const btns = document.querySelectorAll('button');
                    for (const b of btns) {
                        const t = (b.textContent || '').toLowerCase();
                        if (t.includes('continue') || t.includes('verify')) { b.click(); return true; }
                    }
                    return false;
                })()""")
                await asyncio.sleep(3)
            except Exception:
                pass

        # After clicking Continue, try to extract token from the now-navigated page
        if not token:
            await asyncio.sleep(2)
            token = await get_token_from_cdp_storage(page)
            if not token:
                token = await get_token_from_page_eval(page)
            if not token and email and password:
                token = await fetch_discord_token(email, password, proxy_config)

        # Quick single verification check (non-blocking)
        if token:
            try:
                verified = await asyncio.wait_for(check_email_verified_api(token, proxy_config), timeout=12)
                if verified:
                    return True, token
            except Exception:
                pass

        # Always return True if the verify page loaded (Discord showed "Email Verified!")
        return True, token
    except Exception:
        return False, token

async def register_discord_account_in_browser(
    email: str,
    username: str,
    password: str,
    display_name: str = None,
    proxy: str = None,
    mail_api = None,
    timeout: int = 300,
    logger = print
) -> tuple[Optional[str], float]:
    sync_api_key()

    if not display_name:
        first_names = ['Alex', 'Jordan', 'Taylor', 'Morgan', 'Casey', 'Riley', 'Sam', 'Blake', 'Drew', 'Avery', 'Jamie', 'Parker', 'Cameron', 'Dakota', 'Skyler', 'Quinn', 'Reese', 'Sage', 'River', 'Phoenix']
        surnames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Wilson', 'Anderson', 'Taylor', 'Thomas', 'Moore']
        display_name = f"{random.choice(first_names)} {random.choice(surnames)}"

    temp_profile = tempfile.mkdtemp()
    browser = None
    proxy_config = parse_proxy(proxy) if proxy else None

    browser_args = [
        f'--user-data-dir={temp_profile}',
        '--disable-backgrounding-occluded-windows',
        '--disable-background-timer-throttling',
        '--disable-renderer-backgrounding',
        '--disable-throttling',
        '--no-first-run',
        '--disable-default-apps',
        '--disable-features=IsolateOrigins,site-per-process,ChromeWhatsNewUI',
        '--disable-dev-shm-usage',
        '--disable-breakpad',
        '--disable-component-extensions-with-background-pages',
        '--disable-features=TranslateUI,MediaRouter,OptimizationHints',
        '--disable-domain-reliability',
        f'--window-size={BROWSER_WIDTH},{BROWSER_HEIGHT}',
        '--window-position=0,0',
        '--force-device-scale-factor=1',
    ]

    loaded_exts = []
    if os.path.exists(NOPECHA_EXT_DIR):
        loaded_exts.append(os.path.abspath(NOPECHA_EXT_DIR))

    if proxy_config:
        if proxy_config.get('username') and proxy_config.get('password'):
            proxy_ext_dir = create_proxy_extension(proxy_config, temp_profile)
            if proxy_ext_dir:
                loaded_exts.append(os.path.abspath(proxy_ext_dir))
        else:
            browser_args.extend(get_browser_proxy_args(proxy_config))

    if loaded_exts:
        browser_args.append(f'--load-extension={",".join(loaded_exts)}')

    try:
        browser = await uc.start(
            headless=False,
            browser_executable_path=BRAVE_PATH if BRAVE_PATH else None,
            browser_args=browser_args,
        )

        page = await browser.get("https://discord.com/register")
        if not page:
            logger("  [EXT] ✗ Could not load Discord registration page")
            return None, 0.0


        for _ in range(30):
            try:
                if await page.query_selector('input[name="email"]'):
                    break
            except Exception:
                pass
            await asyncio.sleep(0.5)

        await asyncio.sleep(0.5)
        success = await fill_registration_form(page, email, display_name, username, password, logger=logger)
        if not success:
            logger("Registration form fill failed")
            return None, 0.0

        logger("Form submitted, solving captcha with NopeCHA...")
        created, solve_time = await wait_for_account_creation(page, timeout=timeout)
        if not created:
            logger("Account creation timed out or failed")
            return None, 0.0

        token = await wait_for_discord_token(page, timeout=20, email=email, password=password, proxy_config=proxy_config)

        # Email verification
        if mail_api:
            logger("Waiting for verification email...")
            verify_url = mail_api.get_verify_url(email, 3, 180, proxy)
            if verify_url:
                logger("Opening verification URL in browser...")
                try:
                    _, verified_token = await asyncio.wait_for(
                        verify_email_with_url(
                            browser, verify_url, token=token, email=email, password=password, proxy_config=proxy_config
                        ),
                        timeout=60
                    )
                    if verified_token:
                        token = verified_token
                except asyncio.TimeoutError:
                    logger("Verification timeout - continuing with existing token")
                except Exception as ve:
                    logger(f"Verification error: {ve}")
                logger("Verification URL confirmed in browser")

        if not token and email and password:
            token = await fetch_discord_token(email, password, proxy_config)

        if not token:
            logger("Could not extract Discord token")
            return None, solve_time

        return token, solve_time

    except Exception as e:
        logger(f"Browser registration error: {e}")
        return None, 0.0
    finally:
        if browser:
            try:
                browser.stop()
            except Exception:
                pass
        if temp_profile and os.path.exists(temp_profile):
            try:
                shutil.rmtree(temp_profile, ignore_errors=True)
            except Exception:
                pass

def create_discord_account(email, username, password, display_name=None, proxy=None, mail_api=None, timeout=300, logger=print):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(
            register_discord_account_in_browser(
                email=email,
                username=username,
                password=password,
                display_name=display_name,
                proxy=proxy,
                mail_api=mail_api,
                timeout=timeout,
                logger=logger,
            )
        )
    finally:
        try:
            loop.close()
        except Exception:
            pass

class ExtensionBrowser:
    def __init__(self):
        pass

    async def _async_solve(self, sitekey, url, rqdata="", user_agent="", timeout=TASK_TIMEOUT, proxy=None):
        sync_api_key()
        temp_profile = tempfile.mkdtemp()
        browser = None
        proxy_config = parse_proxy(proxy) if proxy else None

        browser_args = [
            f'--user-data-dir={temp_profile}',
            '--disable-backgrounding-occluded-windows',
            '--disable-background-timer-throttling',
            '--disable-renderer-backgrounding',
            '--disable-throttling',
            '--no-first-run',
            '--disable-default-apps',
            '--disable-features=IsolateOrigins,site-per-process,ChromeWhatsNewUI',
            '--disable-dev-shm-usage',
            '--disable-breakpad',
            '--disable-component-extensions-with-background-pages',
            f'--window-size={BROWSER_WIDTH},{BROWSER_HEIGHT}',
            '--window-position=-32000,-32000',
        ]

        loaded_exts = []
        if os.path.exists(NOPECHA_EXT_DIR):
            loaded_exts.append(os.path.abspath(NOPECHA_EXT_DIR))

        if proxy_config:
            if proxy_config.get('username') and proxy_config.get('password'):
                proxy_ext_dir = create_proxy_extension(proxy_config, temp_profile)
                if proxy_ext_dir:
                    loaded_exts.append(os.path.abspath(proxy_ext_dir))
            else:
                browser_args.extend(get_browser_proxy_args(proxy_config))

        if loaded_exts:
            browser_args.append(f'--load-extension={",".join(loaded_exts)}')

        try:
            browser = await uc.start(
                headless=False,
                browser_executable_path=BRAVE_PATH if BRAVE_PATH else None,
                browser_args=browser_args,
            )

            # Generate lightweight hCaptcha runner page
            html_content = f"""<!DOCTYPE html>
<html>
<head>
    <title>NopeCHA Solver</title>
    <script src="https://js.hcaptcha.com/1/api.js" async defer></script>
</head>
<body style="background:#1e1e24; color:#fff; display:flex; justify-content:center; align-items:center; height:100vh; margin:0;">
    <div style="padding:20px; text-align:center;">
        <h4 style="margin:0 0 15px 0; font-family:sans-serif; color:#aaa;">Solving hCaptcha via Extension...</h4>
        <div class="h-captcha" data-sitekey="{sitekey}" data-rqdata="{rqdata}"></div>
    </div>
</body>
</html>"""
            runner_file = os.path.join(temp_profile, "hcaptcha_runner.html")
            with open(runner_file, "w", encoding="utf-8") as f:
                f.write(html_content)

            page = await browser.get(f"file:///{runner_file.replace(os.sep, '/')}")
            if not page:
                return None

            start_t = time.time()
            max_wait = min(timeout, 30)
            while time.time() - start_t < max_wait:
                await asyncio.sleep(1)
                try:
                    token_val = await page.evaluate(
                        'document.querySelector(\'[name="h-captcha-response"]\')?.value || '
                        'document.querySelector(\'[data-hcaptcha-response]\')?.value || ""'
                    )
                    if token_val and len(str(token_val)) > 20:
                        return str(token_val)
                except Exception:
                    pass

            return None
        except Exception as e:
            print(f"  [EXT] Browser solve exception: {e}")
            return None
        finally:
            if browser:
                try:
                    browser.stop()
                except Exception:
                    pass
            if temp_profile and os.path.exists(temp_profile):
                try:
                    shutil.rmtree(temp_profile, ignore_errors=True)
                except Exception:
                    pass

    def solve(self, sitekey, url, rqdata="", user_agent="", timeout=TASK_TIMEOUT, proxy=None):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            return loop.run_until_complete(
                self._async_solve(sitekey, url, rqdata, user_agent, timeout, proxy)
            )
        except Exception as e:
            print(f"  [EXT] Solve error: {e}")
            return None
        finally:
            try:
                loop.close()
            except Exception:
                pass

    def is_ready(self):
        return True

    def stop(self):
        pass

_browsers = {}
def get_browser():
    import threading
    tid = threading.get_ident()
    if tid not in _browsers:
        _browsers[tid] = ExtensionBrowser()
    return _browsers[tid]
