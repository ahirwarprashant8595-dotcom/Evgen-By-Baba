import os
import sys
import time
import json
import concurrent.futures
from typing import List, Tuple, Optional
import urllib.request
import urllib.error

# ANSI colors matching Lord Vault aesthetic
P = "\033[38;2;121;3;255m"
C = "\033[38;2;3;248;252m"
G = "\033[38;2;68;255;0m"
Y = "\033[38;2;252;248;3m"
D = "\033[38;2;92;94;91m"
W = "\033[97m"
RD = "\033[38;2;255;80;80m"
R = "\033[0m"

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
INPUT_FILE = os.path.join(BASE_DIR, "input", "proxies.txt")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
WORKING_FILE = os.path.join(OUTPUT_DIR, "working_proxies.txt")

TEST_URL = "https://discord.com/api/v9/experiments"
TIMEOUT = 6

def format_proxy(raw: str) -> Optional[Tuple[str, str]]:
    raw = raw.strip()
    if not raw or raw.startswith("#"):
        return None
    
    clean = raw
    for prefix in ("http://", "https://", "socks5://", "socks4://"):
        if clean.startswith(prefix):
            clean = clean[len(prefix):]
            break
            
    parts = clean.split(":")
    if "@" in clean:
        return (raw, f"http://{clean}")
    if len(parts) == 4:
        ip, port, user, pwd = parts
        return (raw, f"http://{user}:{pwd}@{ip}:{port}")
    if len(parts) == 2:
        return (raw, f"http://{clean}")
    return (raw, f"http://{clean}")

def load_proxies() -> List[Tuple[str, str]]:
    search_paths = [
        INPUT_FILE,
        os.path.join(BASE_DIR, "proxies.txt"),
    ]
    for path in search_paths:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                lines = [line.strip() for line in f if line.strip()]
            valid = []
            for line in lines:
                p = format_proxy(line)
                if p:
                    valid.append(p)
            return valid
    return []

def check_proxy(proxy_tuple: Tuple[str, str]) -> Tuple[str, str, int]:
    raw, proxy_url = proxy_tuple
    start_time = time.time()
    try:
        handler = urllib.request.ProxyHandler({'http': proxy_url, 'https': proxy_url})
        opener = urllib.request.build_opener(handler)
        req = urllib.request.Request(
            TEST_URL,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
                "Accept": "*/*"
            }
        )
        with opener.open(req, timeout=TIMEOUT) as resp:
            elapsed = int((time.time() - start_time) * 1000)
            if resp.status in (200, 204, 401, 403):
                if resp.status == 403:
                    return ("BLOCKED", raw, elapsed)
                return ("WORKING", raw, elapsed)
            return ("DEAD", raw, elapsed)
    except urllib.error.HTTPError as e:
        elapsed = int((time.time() - start_time) * 1000)
        if e.code in (401, 404):
            return ("WORKING", raw, elapsed)
        if e.code == 403:
            return ("BLOCKED", raw, elapsed)
        return ("DEAD", raw, elapsed)
    except Exception:
        return ("DEAD", raw, 0)

def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    # Заголовок утилиты проверки прокси
    if os.environ.get("GUI_MODE") != "1":
        print(f"\n  {P}┌───────────────────────────────────────────────┐{R}")
        print(f"  {P}│{R}  {C}Lord Vault Proxy Checker{R}                     {P}│{R}")
        print(f"  {P}└───────────────────────────────────────────────┘{R}\n")

    proxies = load_proxies()
    total = len(proxies)

    if total == 0:
        print(f"  {RD}[!] No proxies found in input/proxies.txt{R}")
        return

    max_workers = 50
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg = json.load(f)
                max_workers = cfg.get("threading", {}).get("proxy_checker", 50)
        except Exception:
            pass

    print(f"  {C}[*] Proxies: {total}{R} | Threads: {max_workers}")
    print(f"  {D}Testing connectivity against Discord gateway...{R}\n")

    working = 0
    dead = 0
    blocked = 0

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    working_file_handle = open(WORKING_FILE, "w", encoding="utf-8")

    # Параллельная проверка соединений с шлюзом Discord через пул потоков
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(check_proxy, p): p for p in proxies}
        
        for future in concurrent.futures.as_completed(futures):
            status, raw_proxy, latency = future.result()
            
            if status == "WORKING":
                working += 1
                working_file_handle.write(raw_proxy + "\n")
                working_file_handle.flush()
                print(f"  {G}[✓] WORKING{R} │ {W}{raw_proxy}{R} │ {C}{latency}ms{R}")
            elif status == "BLOCKED":
                blocked += 1
                print(f"  {Y}[!] BLOCKED{R} │ {D}{raw_proxy}{R}")
            else:
                dead += 1
                print(f"  {RD}[✗] DEAD   {R} │ {D}{raw_proxy}{R}")

            print(f"GUI_STAT:{working},{working},0,0,{blocked},{dead},{total}")

    working_file_handle.close()

    print(f"\n  {P}───────────────────────────────────────────────{R}")
    print(f"  {G}Working : {working}{R}")
    print(f"  {RD}Dead    : {dead}{R}")
    print(f"  {Y}Blocked : {blocked}{R}")
    print(f"  {C}Total   : {total}{R}")
    print(f"  {D}Saved working proxies to: output/working_proxies.txt{R}\n")

if __name__ == "__main__":
    main()
